package com.uwimona.group25.calculuscal.syntax;

public abstract class Statement extends ASTNode {

    private static final long serialVersionUID = 1L;

}
