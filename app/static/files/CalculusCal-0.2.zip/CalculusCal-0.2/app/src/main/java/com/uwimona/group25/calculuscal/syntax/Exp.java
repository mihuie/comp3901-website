package com.uwimona.group25.calculuscal.syntax;

public abstract class Exp extends Statement {
}
