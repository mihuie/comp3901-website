package com.uwimona.group25.calculuscal.exception;


public class CalcDimensionException extends RuntimeException {

	private static final long serialVersionUID = 4298179502229064227L;

	public CalcDimensionException(String message) {
		super(message);
	}
}
